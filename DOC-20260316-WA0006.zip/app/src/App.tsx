import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Snowflake, 
  Wrench, 
  Wind, 
  Droplets, 
  Phone, 
  MapPin, 
  Clock, 
  Star, 
  CheckCircle,
  Menu,
  X,
  User,
  ChevronRight
} from 'lucide-react'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [showOrderDialog, setShowOrderDialog] = useState(false)
  const [selectedService, setSelectedService] = useState('')
  const [orderSubmitted, setOrderSubmitted] = useState(false)

  const services = [
    {
      id: 'cleaning',
      title: 'Cuci AC',
      description: 'Pembersihan AC standar untuk menjaga kualitas udara dan efisiensi pendingin',
      price: 'Rp 75.000',
      unit: '/unit',
      icon: <Droplets className="w-8 h-8" />,
      features: ['Pembersihan filter', 'Pembersihan evaporator', 'Pembersihan blower', 'Cek freon']
    },
    {
      id: 'service',
      title: 'Service AC',
      description: 'Perawatan menyeluruh untuk memastikan AC berfungsi optimal',
      price: 'Rp 150.000',
      unit: '/unit',
      icon: <Wrench className="w-8 h-8" />,
      features: ['Cuci AC lengkap', 'Cek tekanan freon', 'Cek kompresor', 'Cek kelistrikan']
    },
    {
      id: 'install',
      title: 'Pasang AC',
      description: 'Instalasi AC baru dengan standar profesional dan bergaransi',
      price: 'Rp 350.000',
      unit: '/unit',
      icon: <Wind className="w-8 h-8" />,
      features: ['Instalasi standar', 'Pemasangan pipa', 'Vacuum sistem', 'Test running']
    },
    {
      id: 'freon',
      title: 'Isi Freon',
      description: 'Pengisian freon dengan ukuran yang tepat untuk performa maksimal',
      price: 'Rp 100.000',
      unit: '/unit',
      icon: <Snowflake className="w-8 h-8" />,
      features: ['Cek kebocoran', 'Isi freon R32/R410', 'Test tekanan', 'Garansi 1 bulan']
    }
  ]

  const testimonials = [
    {
      name: 'Budi Santoso',
      location: 'Jakarta Selatan',
      rating: 5,
      comment: 'Pelayanan sangat memuaskan, teknisi datang tepat waktu dan AC jadi dingin lagi!'
    },
    {
      name: 'Siti Rahayu',
      location: 'Jakarta Barat',
      rating: 5,
      comment: 'Harga terjangkau dan hasil kerja rapi. Sangat recommended!'
    },
    {
      name: 'Ahmad Wijaya',
      location: 'Jakarta Timur',
      rating: 5,
      comment: 'Sudah 3 kali pakai jasa ini, selalu puas dengan pelayanannya.'
    }
  ]

  const handleOrderClick = (serviceId: string) => {
    setSelectedService(serviceId)
    setShowOrderDialog(true)
    setOrderSubmitted(false)
  }

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault()
    setOrderSubmitted(true)
    setTimeout(() => {
      setShowOrderDialog(false)
    }, 2000)
  }

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMenuOpen(false)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Snowflake className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">JasaAC</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-gray-600 hover:text-blue-600 transition-colors">Beranda</button>
              <button onClick={() => scrollToSection('services')} className="text-gray-600 hover:text-blue-600 transition-colors">Layanan</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-gray-600 hover:text-blue-600 transition-colors">Testimoni</button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-600 hover:text-blue-600 transition-colors">Kontak</button>
              <Button onClick={() => scrollToSection('services')} className="bg-blue-600 hover:bg-blue-700">
                Pesan Sekarang
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100">
            <div className="px-4 py-4 space-y-3">
              <button onClick={() => scrollToSection('home')} className="block w-full text-left py-2 text-gray-600">Beranda</button>
              <button onClick={() => scrollToSection('services')} className="block w-full text-left py-2 text-gray-600">Layanan</button>
              <button onClick={() => scrollToSection('testimonials')} className="block w-full text-left py-2 text-gray-600">Testimoni</button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left py-2 text-gray-600">Kontak</button>
              <Button onClick={() => scrollToSection('services')} className="w-full bg-blue-600 hover:bg-blue-700">
                Pesan Sekarang
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 px-4 py-1">
                Layanan Profesional & Terpercaya
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Solusi AC Anda <span className="text-blue-600">Berkualitas</span>
              </h1>
              <p className="text-lg text-gray-600 leading-relaxed">
                Layanan cuci, service, dan pasang AC profesional dengan teknisi berpengalaman. 
                Datang tepat waktu, harga transparan, dan bergaransi.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={() => scrollToSection('services')}
                  className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-6"
                >
                  Pesan Layanan
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => scrollToSection('contact')}
                  className="text-lg px-8 py-6 border-gray-300"
                >
                  Hubungi Kami
                </Button>
              </div>
              <div className="flex items-center space-x-6 pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Teknisi Profesional</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-gray-600">Garansi Service</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="bg-blue-600 rounded-3xl p-8 md:p-12 text-white">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <div className="text-3xl md:text-4xl font-bold">1000+</div>
                    <div className="text-blue-100 text-sm mt-1">Pelanggan Puas</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl md:text-4xl font-bold">5+</div>
                    <div className="text-blue-100 text-sm mt-1">Tahun Pengalaman</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl md:text-4xl font-bold">24/7</div>
                    <div className="text-blue-100 text-sm mt-1">Layanan</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl md:text-4xl font-bold">100%</div>
                    <div className="text-blue-100 text-sm mt-1">Bergaransi</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 mb-4">
              Layanan Kami
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Pilih Layanan yang Anda Butuhkan
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Kami menyediakan berbagai layanan AC dengan harga terjangkau dan kualitas terbaik
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <Card key={service.id} className="group hover:shadow-xl transition-shadow border-gray-200">
                <CardHeader className="pb-4">
                  <div className="bg-blue-50 w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:bg-blue-100 transition-colors">
                    <div className="text-blue-600">{service.icon}</div>
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-gray-500">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <span className="text-2xl font-bold text-blue-600">{service.price}</span>
                    <span className="text-gray-500 text-sm">{service.unit}</span>
                  </div>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    onClick={() => handleOrderClick(service.id)}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    Pesan Sekarang
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 mb-4">
              Keunggulan Kami
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Mengapa Memilih JasaAC?
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm">
              <div className="bg-blue-100 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                <User className="w-7 h-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Teknisi Profesional</h3>
              <p className="text-gray-600">
                Tim teknisi kami berpengalaman dan tersertifikasi dengan training berkala
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm">
              <div className="bg-blue-100 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                <Clock className="w-7 h-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Tepat Waktu</h3>
              <p className="text-gray-600">
                Kami menghargai waktu Anda. Teknisi datang sesuai jadwal yang disepakati
              </p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm">
              <div className="bg-blue-100 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                <CheckCircle className="w-7 h-7 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Garansi Layanan</h3>
              <p className="text-gray-600">
                Semua layanan kami dilengkapi dengan garansi untuk ketenangan pikiran Anda
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 mb-4">
              Testimoni
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Apa Kata Pelanggan Kami
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, idx) => (
              <Card key={idx} className="border-gray-200">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">"{testimonial.comment}"</p>
                  <div className="flex items-center">
                    <div className="bg-blue-100 w-10 h-10 rounded-full flex items-center justify-center mr-3">
                      <User className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">{testimonial.name}</div>
                      <div className="text-sm text-gray-500">{testimonial.location}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-24 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Butuh Bantuan AC Segera?
              </h2>
              <p className="text-blue-100 mb-8 text-lg">
                Hubungi kami sekarang untuk konsultasi gratis dan penjadwalan layanan
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="bg-white/10 p-3 rounded-lg">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-blue-100 text-sm">Telepon/WhatsApp</div>
                    <div className="text-xl font-semibold">0812-3456-7890</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="bg-white/10 p-3 rounded-lg">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-blue-100 text-sm">Jam Operasional</div>
                    <div className="text-xl font-semibold">Senin - Minggu, 08:00 - 20:00</div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="bg-white/10 p-3 rounded-lg">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-blue-100 text-sm">Area Layanan</div>
                    <div className="text-xl font-semibold">Jakarta & Sekitarnya</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Kirim Pesan</h3>
              <form className="space-y-4">
                <div>
                  <Label htmlFor="name">Nama Lengkap</Label>
                  <Input id="name" placeholder="Masukkan nama Anda" className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="phone">Nomor Telepon</Label>
                  <Input id="phone" placeholder="Masukkan nomor telepon" className="mt-1" />
                </div>
                <div>
                  <Label htmlFor="message">Pesan</Label>
                  <Textarea id="message" placeholder="Tulis pesan Anda..." className="mt-1" rows={4} />
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">
                  Kirim Pesan
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <Snowflake className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">JasaAC</span>
              </div>
              <p className="text-gray-400 text-sm">
                Layanan AC profesional dengan teknisi berpengalaman. 
                Kepuasan pelanggan adalah prioritas kami.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Layanan</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>Cuci AC</li>
                <li>Service AC</li>
                <li>Pasang AC</li>
                <li>Isi Freon</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Tautan</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><button onClick={() => scrollToSection('home')} className="hover:text-white">Beranda</button></li>
                <li><button onClick={() => scrollToSection('services')} className="hover:text-white">Layanan</button></li>
                <li><button onClick={() => scrollToSection('testimonials')} className="hover:text-white">Testimoni</button></li>
                <li><button onClick={() => scrollToSection('contact')} className="hover:text-white">Kontak</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Kontak</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>0812-3456-7890</li>
                <li>info@jasaac.com</li>
                <li>Jakarta, Indonesia</li>
              </ul>
            </div>
          </div>
          <Separator className="my-8 bg-gray-800" />
          <div className="text-center text-gray-400 text-sm">
            © 2024 JasaAC. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Order Dialog */}
      <Dialog open={showOrderDialog} onOpenChange={setShowOrderDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Pesan Layanan</DialogTitle>
            <DialogDescription>
              Isi formulir berikut untuk memesan layanan AC
            </DialogDescription>
          </DialogHeader>
          
          {orderSubmitted ? (
            <div className="text-center py-8">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Pesanan Berhasil!</h3>
              <p className="text-gray-600">Kami akan menghubungi Anda segera.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmitOrder} className="space-y-4">
              <div>
                <Label htmlFor="order-name">Nama Lengkap</Label>
                <Input id="order-name" placeholder="Masukkan nama Anda" required className="mt-1" />
              </div>
              <div>
                <Label htmlFor="order-phone">Nomor Telepon</Label>
                <Input id="order-phone" placeholder="Masukkan nomor telepon" required className="mt-1" />
              </div>
              <div>
                <Label htmlFor="order-address">Alamat</Label>
                <Textarea id="order-address" placeholder="Masukkan alamat lengkap" required className="mt-1" rows={3} />
              </div>
              <div>
                <Label htmlFor="order-service">Layanan</Label>
                <Select defaultValue={selectedService}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Pilih layanan" />
                  </SelectTrigger>
                  <SelectContent>
                    {services.map((s) => (
                      <SelectItem key={s.id} value={s.id}>{s.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="order-date">Tanggal Kunjungan</Label>
                <Input id="order-date" type="date" required className="mt-1" />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Konfirmasi Pesanan
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default App
